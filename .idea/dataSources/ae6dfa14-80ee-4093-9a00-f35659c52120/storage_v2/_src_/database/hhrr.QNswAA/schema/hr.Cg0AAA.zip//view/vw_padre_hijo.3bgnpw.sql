create view vw_padre_hijo(padre, hijo, edad) as
SELECT (p.nombre::text || ' '::text) || p.apellido::text AS padre,
       (h.nombre::text || ' '::text) || h.apellido::text AS hijo,
       h.edad
FROM hr.padre p
         JOIN hr.hijo h ON p.id = h.id_padre;

alter table vw_padre_hijo
    owner to postgres;

grant select on vw_padre_hijo to hr_lectura;

grant delete, insert, references, select, trigger, truncate, update on vw_padre_hijo to hr_escritura;

